﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactManager.Models
{
    public static class SampleData
    {
        static Contact[] sampleContacts = new Contact[]
            {
                new Contact { ContactId = 1, FName = "Rita", LName = "Pillai", PhoneNo = "2225533698", Status = "Active", Email = "rpillai@microsoft.com"},
                new Contact { ContactId = 2, FName = "Tara", LName = "Deshmukh", PhoneNo = "7778844536", Status = "Active", Email = "deshmukhtara@microsoft.com"},
                new Contact { ContactId = 3, FName = "Eka", LName = "Gandhi", PhoneNo = "3369871669", Status = "Inactive", Email = "eka.gandhi@microsoft.com"},
                new Contact { ContactId = 4, FName = "Manushri", LName = "Chillar", PhoneNo = "4445569872", Status = "Inactive", Email = "manuc@microsoft.com"},
                new Contact { ContactId = 5, FName = "Ekta", LName = "Sahastrabuddhe", PhoneNo = "6698754658", Status = "Inactive", Email = "ektas@microsoft.com"},
            };

        public static Contact[] Contacts
        {
            get
            {
                return sampleContacts;
            }
        }
    }
}